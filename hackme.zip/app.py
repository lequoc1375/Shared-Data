from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this in production!

# Simple user database (in production, use a proper database)
users = {
    'admin': generate_password_hash('password123')
}

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('badvibes'))
    return render_template('index.html')

@app.route('/badvibes')
def badvibes():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('badvibes.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in users and check_password_hash(users[username], password):
            session['username'] = username
            return redirect(url_for('badvibes'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000) 